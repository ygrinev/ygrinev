var Rectangle = function(x, y, width, height)
{
	this.x = x;
	this.y = y;
	this.width = width;
	this.height = height;
	
	this.draw = function(color)
	{
		gfx.beginPath();
		gfx.rect(this.x, this.y, this.width, this.height);
		gfx.strokeStyle = color;
		gfx.stroke();		
	}
	
	this.rectInside = function( rect )
	{
		if (this.x < rect.x + rect.width && this.x + this.width > rect.x &&
		    this.y < rect.y + rect.height && this.y + this.height > rect.y) {
		    	return true;
		    }
		return false;		    
	}
	
	this.pointInside = function(px, py)
	{
		var px = px;
		var py = py;
		if (arguments.length == 1) {
			var pt = new Point(px.x, px.y);
			px = pt.x;
			py = pt.y;
		}
		if (px >= this.x && px <= this.x + this.width)
		{
			if (py >= this.y && py <= this.y + this.height)
			{
				return true;
			}
		}
		return false;
	}
	
}