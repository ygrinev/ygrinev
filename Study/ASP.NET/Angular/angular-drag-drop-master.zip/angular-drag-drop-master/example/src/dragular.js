require("./dragular.css");

var Angular = require("angular");

Angular.module("dragular", [
    require("../../"),

    require("controllers/game"),
]);