"Breeze for ASP.NET Web Api projects" ReadMe
------------------------------------------
This Breeze NuGet Package adds essential Breeze script files 
and .NET Web Api libraries to your project.

For an example of a Breeze application, add the
 'Breeze.WebApiSample' package to your project.

Visit http://www.breezejs.com/documentation/start-nuget to learn more.

The following files and references were add to this project.

Two referenced assemblies

	Breeze.WebApi
	Irony
	Entity Framework

Five scripts

	Scripts/breeze.min.js
	Scripts/breeze.debug.js
    Scripts/breeze.intellisense.js
	Scripts/q.js
	Scripts/q.min.js

One configuration file

	App_Start/BreezeWebApiConfig.cs 
